
import { useState } from 'react';
import { MessageSquare, Send, Bot } from 'lucide-react';
import { Link } from 'react-router-dom';

const ChatbotPreview = () => {
  const [message, setMessage] = useState('');
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real implementation, this would send the message to an API
    setMessage('');
  };

  return (
    <section className="py-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-center lg:space-x-12">
          <div className="lg:w-1/2 mb-8 lg:mb-0">
            <h2 className="text-3xl font-bold mb-4">
              Meet IIT Mind Bot
            </h2>
            <p className="text-xl text-muted-foreground mb-6">
              Our AI-powered mental health companion is here to provide immediate support, 
              guide you to helpful resources, and connect you with counselors when needed.
            </p>
            <ul className="space-y-4 mb-8">
              <li className="flex items-start">
                <div className="flex-shrink-0 h-6 w-6 rounded-full bg-mindblue-600/20 flex items-center justify-center mt-1">
                  <span className="text-mindblue-500 font-bold text-sm">✓</span>
                </div>
                <p className="ml-3">
                  <span className="font-semibold">Available 24/7</span> - Get help whenever you need it
                </p>
              </li>
              <li className="flex items-start">
                <div className="flex-shrink-0 h-6 w-6 rounded-full bg-mindblue-600/20 flex items-center justify-center mt-1">
                  <span className="text-mindblue-500 font-bold text-sm">✓</span>
                </div>
                <p className="ml-3">
                  <span className="font-semibold">Complete Privacy</span> - Your conversations are confidential
                </p>
              </li>
              <li className="flex items-start">
                <div className="flex-shrink-0 h-6 w-6 rounded-full bg-mindblue-600/20 flex items-center justify-center mt-1">
                  <span className="text-mindblue-500 font-bold text-sm">✓</span>
                </div>
                <p className="ml-3">
                  <span className="font-semibold">Personalized Support</span> - Tailored to IIT student challenges
                </p>
              </li>
            </ul>
            <Link to="/chat" className="btn-primary inline-flex items-center space-x-2">
              <MessageSquare className="h-4 w-4" />
              <span>Start Chatting Now</span>
            </Link>
          </div>
          
          <div className="lg:w-1/2">
            <div className="mindcard shadow-lg rounded-xl overflow-hidden max-w-md mx-auto">
              <div className="bg-mindblue-600 text-white p-4 flex items-center space-x-2">
                <Bot className="h-6 w-6" />
                <h3 className="font-semibold">IIT Mind Bot</h3>
              </div>
              
              <div className="bg-muted h-72 p-4 overflow-y-auto">
                <div className="mb-4">
                  <div className="flex items-start space-x-2">
                    <div className="bg-mindblue-800/30 text-foreground rounded-lg p-3 max-w-xs">
                      <p className="text-sm">
                        Hello! I'm IIT Mind Bot. I'm here to help with your mental wellbeing. 
                        How are you feeling today?
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="mb-4">
                  <div className="flex items-start justify-end space-x-2">
                    <div className="bg-mindblue-600 rounded-lg p-3 max-w-xs">
                      <p className="text-sm text-white">
                        I've been feeling overwhelmed with my coursework lately.
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="mb-4">
                  <div className="flex items-start space-x-2">
                    <div className="bg-mindblue-800/30 text-foreground rounded-lg p-3 max-w-xs">
                      <p className="text-sm">
                        I understand that feeling overwhelmed with coursework can be challenging. 
                        You're not alone in this. Would you like me to share some strategies for 
                        managing academic stress, or connect you with an academic counselor?
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="text-center text-xs text-muted-foreground mt-2">
                  Try a demo conversation in the preview
                </div>
              </div>
              
              <div className="bg-background p-3 border-t border-border">
                <form onSubmit={handleSubmit} className="flex items-center space-x-2">
                  <input
                    type="text"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Type a message..."
                    className="flex-1 bg-input border border-border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-mindblue-500 text-sm"
                  />
                  <button 
                    type="submit" 
                    className="bg-mindblue-600 text-white p-2 rounded-lg hover:bg-mindblue-700"
                  >
                    <Send className="h-4 w-4" />
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ChatbotPreview;
