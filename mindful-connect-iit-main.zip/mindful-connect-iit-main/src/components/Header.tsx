
import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Menu, X, Brain, Moon, Sun, User, LogOut, MessageSquare } from 'lucide-react';
import { Toggle } from "@/components/ui/toggle";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "../context/AuthContext";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user, profile, signOut } = useAuth();

  // Check for user's preferred color scheme
  useEffect(() => {
    const storedTheme = localStorage.getItem('theme');
    if (storedTheme === 'dark' || 
      (!storedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      document.documentElement.classList.add('dark');
      setIsDarkMode(true);
    } else {
      document.documentElement.classList.remove('dark');
      setIsDarkMode(false);
    }
  }, []);

  const toggleTheme = () => {
    if (document.documentElement.classList.contains('dark')) {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
      setIsDarkMode(false);
    } else {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
      setIsDarkMode(true);
    }
  };

  const handleSignIn = () => {
    navigate('/login');
  };

  const handleSignOut = async () => {
    await signOut();
  };

  const getInitials = (fullName: string) => {
    if (!fullName) return 'U';
    return fullName.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50 dark:bg-gray-900 dark:text-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-2">
            <Brain className="h-8 w-8 text-mindblue-600 dark:text-mindblue-400" />
            <Link to="/" className="font-bold text-xl text-mindblue-900 dark:text-mindblue-300">
              IIT Mind
            </Link>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link to="/" className="font-medium text-gray-700 hover:text-mindblue-600 transition-colors duration-200 dark:text-gray-200 dark:hover:text-mindblue-400">
              Home
            </Link>
            <Link to="/chat" className="font-medium text-gray-700 hover:text-mindblue-600 transition-colors duration-200 dark:text-gray-200 dark:hover:text-mindblue-400">
              Chat
            </Link>
            <Link to="/counselors" className="font-medium text-gray-700 hover:text-mindblue-600 transition-colors duration-200 dark:text-gray-200 dark:hover:text-mindblue-400">
              Counselors
            </Link>
            <Link to="/resources" className="font-medium text-gray-700 hover:text-mindblue-600 transition-colors duration-200 dark:text-gray-200 dark:hover:text-mindblue-400">
              Resources
            </Link>
            <Toggle 
              pressed={isDarkMode}
              onPressedChange={toggleTheme}
              aria-label="Toggle dark mode"
              className="p-2"
            >
              {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Toggle>
            
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger className="outline-none">
                  <Avatar className="h-9 w-9 cursor-pointer hover:ring-2 hover:ring-mindblue-500 transition-all">
                    <AvatarImage src={profile?.avatar_url} />
                    <AvatarFallback className="bg-mindblue-100 text-mindblue-800 dark:bg-mindblue-900 dark:text-mindblue-200">
                      {profile?.full_name ? getInitials(profile.full_name) : 'U'}
                    </AvatarFallback>
                  </Avatar>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <div className="px-4 py-3">
                    <p className="text-sm font-medium leading-none">{profile?.full_name || 'User'}</p>
                    <p className="text-xs text-muted-foreground mt-1 truncate">{user.email}</p>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => navigate('/profile')} className="cursor-pointer">
                    <User className="mr-2 h-4 w-4" />
                    <span>Profile</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate('/chat')} className="cursor-pointer">
                    <MessageSquare className="mr-2 h-4 w-4" />
                    <span>My Chats</span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleSignOut} className="cursor-pointer text-red-600 dark:text-red-400">
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Sign out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <button 
                className="btn-primary dark:bg-mindblue-700 dark:hover:bg-mindblue-800"
                onClick={handleSignIn}
              >
                Sign In
              </button>
            )}
          </nav>
          
          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center space-x-4">
            <Toggle 
              pressed={isDarkMode}
              onPressedChange={toggleTheme}
              aria-label="Toggle dark mode"
              className="p-2"
            >
              {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Toggle>
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-gray-700 dark:text-gray-200 hover:text-mindblue-600 dark:hover:text-mindblue-400 focus:outline-none"
              aria-label="Toggle Menu"
            >
              {isOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>
        
        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden py-4 animate-fade-in">
            <div className="flex flex-col space-y-4">
              <Link 
                to="/" 
                className="font-medium text-gray-700 hover:text-mindblue-600 transition-colors duration-200 dark:text-gray-200 dark:hover:text-mindblue-400"
                onClick={() => setIsOpen(false)}
              >
                Home
              </Link>
              <Link 
                to="/chat" 
                className="font-medium text-gray-700 hover:text-mindblue-600 transition-colors duration-200 dark:text-gray-200 dark:hover:text-mindblue-400"
                onClick={() => setIsOpen(false)}
              >
                Chat
              </Link>
              <Link 
                to="/counselors" 
                className="font-medium text-gray-700 hover:text-mindblue-600 transition-colors duration-200 dark:text-gray-200 dark:hover:text-mindblue-400"
                onClick={() => setIsOpen(false)}
              >
                Counselors
              </Link>
              <Link 
                to="/resources" 
                className="font-medium text-gray-700 hover:text-mindblue-600 transition-colors duration-200 dark:text-gray-200 dark:hover:text-mindblue-400"
                onClick={() => setIsOpen(false)}
              >
                Resources
              </Link>
              {user ? (
                <>
                  <Link
                    to="/profile"
                    className="font-medium text-gray-700 hover:text-mindblue-600 transition-colors duration-200 dark:text-gray-200 dark:hover:text-mindblue-400"
                    onClick={() => setIsOpen(false)}
                  >
                    Profile
                  </Link>
                  <button
                    onClick={() => {
                      handleSignOut();
                      setIsOpen(false);
                    }}
                    className="text-left font-medium text-red-600 hover:text-red-700 transition-colors duration-200 dark:text-red-400 dark:hover:text-red-300"
                  >
                    Sign Out
                  </button>
                </>
              ) : (
                <button 
                  className="btn-primary dark:bg-mindblue-700 dark:hover:bg-mindblue-800 w-full"
                  onClick={() => {
                    handleSignIn();
                    setIsOpen(false);
                  }}
                >
                  Sign In
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
