
import { MessageSquare, Users, BookOpen, Shield } from 'lucide-react';

const Features = () => {
  const features = [
    {
      icon: <MessageSquare className="h-8 w-8 text-mindblue-600" />,
      title: "AI Chatbot Support",
      description: "Get immediate help from our AI-powered 'IIT Mind Bot' for initial guidance and coping strategies."
    },
    {
      icon: <Users className="h-8 w-8 text-mindpurple-600" />,
      title: "Anonymous Counseling",
      description: "Connect with professional counselors while maintaining your privacy and anonymity."
    },
    {
      icon: <BookOpen className="h-8 w-8 text-mindteal-600" />,
      title: "Mental Health Resources",
      description: "Access a curated collection of articles, guides, and tools specific to IIT Madras students."
    },
    {
      icon: <Shield className="h-8 w-8 text-mindblue-600" />,
      title: "Secure & Private",
      description: "Your identity remains protected while using our platform, with strict privacy controls."
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900">How IIT Mind Helps You</h2>
          <p className="mt-4 text-xl text-gray-600 max-w-2xl mx-auto">
            Supporting your mental wellbeing with innovative tools and professional guidance
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="mindcard p-6 hover:translate-y-[-8px]"
            >
              <div className="mb-4">{feature.icon}</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
