
import { useState } from 'react';
import { ChevronLeft, ChevronRight, Star } from 'lucide-react';

const testimonials = [
  {
    id: 1,
    text: "IIT Mind helped me manage my academic stress during my third semester. The counselor provided practical strategies that really worked with my packed schedule.",
    name: "Arjun K.",
    year: "2nd Year BS Student",
    rating: 5
  },
  {
    id: 2,
    text: "The anonymous chat feature made all the difference for me. I was hesitant to seek help initially, but being able to talk privately gave me the confidence to open up.",
    name: "Priya S.",
    year: "3rd Year BS Student",
    rating: 5
  },
  {
    id: 3,
    text: "IIT Mind Bot was surprisingly helpful with immediate suggestions when I was experiencing anxiety before my exams. It guided me through some breathing exercises that calmed me down.",
    name: "Rahul M.",
    year: "1st Year BS Student",
    rating: 4
  },
  {
    id: 4,
    text: "The mindfulness resources helped me develop a daily meditation practice that improved my focus and reduced stress. I'm more productive and balanced now.",
    name: "Sneha V.",
    year: "4th Year BS Student",
    rating: 5
  },
  {
    id: 5,
    text: "When I was struggling with imposter syndrome, my counselor at IIT Mind helped me understand that many students feel the same way. The strategies they suggested really helped.",
    name: "Vikram T.",
    year: "2nd Year BS Student",
    rating: 5
  }
];

const Testimonials = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  
  const nextTestimonial = () => {
    setActiveIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
  };
  
  const prevTestimonial = () => {
    setActiveIndex((prevIndex) => (prevIndex - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section className="py-16 bg-mindblue-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900">Student Experiences</h2>
          <p className="mt-4 text-xl text-gray-600 max-w-2xl mx-auto">
            Hear from IIT Madras students who've benefited from our mental wellness support
          </p>
        </div>
        
        <div className="max-w-4xl mx-auto relative">
          <div className="mindcard shadow-md p-8 md:p-10 min-h-[250px]">
            <div className="flex mb-6">
              {[...Array(testimonials[activeIndex].rating)].map((_, i) => (
                <Star key={i} className="h-5 w-5 text-yellow-500 fill-yellow-500" />
              ))}
              {[...Array(5 - testimonials[activeIndex].rating)].map((_, i) => (
                <Star key={i + testimonials[activeIndex].rating} className="h-5 w-5 text-gray-300" />
              ))}
            </div>
            
            <blockquote className="text-lg text-gray-700 italic mb-6">
              "{testimonials[activeIndex].text}"
            </blockquote>
            
            <div>
              <p className="font-semibold text-gray-900">{testimonials[activeIndex].name}</p>
              <p className="text-gray-600 text-sm">{testimonials[activeIndex].year}</p>
            </div>
          </div>
          
          <div className="flex justify-center mt-6 space-x-2">
            {testimonials.map((_, index) => (
              <button 
                key={index}
                onClick={() => setActiveIndex(index)}
                className={`h-2 w-2 rounded-full transition-colors ${
                  index === activeIndex ? 'bg-mindblue-600' : 'bg-gray-300'
                }`}
                aria-label={`Go to testimonial ${index + 1}`}
              />
            ))}
          </div>
          
          <button 
            onClick={prevTestimonial}
            className="absolute top-1/2 -translate-y-1/2 -left-4 lg:-left-12 h-10 w-10 bg-white shadow-md rounded-full flex items-center justify-center hover:bg-gray-50"
            aria-label="Previous testimonial"
          >
            <ChevronLeft className="h-6 w-6 text-gray-700" />
          </button>
          
          <button 
            onClick={nextTestimonial}
            className="absolute top-1/2 -translate-y-1/2 -right-4 lg:-right-12 h-10 w-10 bg-white shadow-md rounded-full flex items-center justify-center hover:bg-gray-50"
            aria-label="Next testimonial"
          >
            <ChevronRight className="h-6 w-6 text-gray-700" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
