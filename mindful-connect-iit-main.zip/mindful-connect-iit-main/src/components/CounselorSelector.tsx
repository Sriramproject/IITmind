
import { X } from 'lucide-react';
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

interface CounselorSelectorProps {
  onClose: () => void;
}

const specializations = [
  { id: 'academic', name: 'Academic Stress' },
  { id: 'relationship', name: 'Relationship Issues' },
  { id: 'mental', name: 'Mental Health Support' },
  { id: 'health', name: 'Health & Lifestyle' }
];

const CounselorSelector = ({ onClose }: CounselorSelectorProps) => {
  const [selectedSpecialization, setSelectedSpecialization] = useState<string | null>(null);
  const navigate = useNavigate();
  
  useEffect(() => {
    // Prevent body scrolling when modal is open
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, []);
  
  const handleContinue = () => {
    if (selectedSpecialization) {
      navigate(`/counselors?specialization=${selectedSpecialization}`);
    } else {
      navigate('/counselors');
    }
    onClose();
  };
  
  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-card rounded-xl shadow-lg max-w-md w-full p-6 relative">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-muted-foreground hover:text-foreground"
        >
          <X className="h-5 w-5" />
        </button>
        
        <h2 className="text-xl font-bold mb-4">Connect with a Counselor</h2>
        <p className="text-muted-foreground mb-6">
          Please select the type of counselor you'd like to speak with
        </p>
        
        <div className="space-y-3 mb-6">
          {specializations.map((spec) => (
            <button
              key={spec.id}
              onClick={() => setSelectedSpecialization(spec.id)}
              className={`w-full p-3 rounded-lg border text-left transition-colors ${
                selectedSpecialization === spec.id
                  ? 'border-mindblue-500 bg-mindblue-500/10'
                  : 'border-border hover:bg-muted'
              }`}
            >
              <span className="font-medium">{spec.name}</span>
            </button>
          ))}
        </div>
        
        <div className="flex justify-end gap-3">
          <button 
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-muted hover:bg-muted/70 text-foreground"
          >
            Cancel
          </button>
          <button 
            onClick={handleContinue}
            className="px-4 py-2 rounded-lg bg-mindblue-600 hover:bg-mindblue-700 text-white"
          >
            Continue
          </button>
        </div>
      </div>
    </div>
  );
};

export default CounselorSelector;
