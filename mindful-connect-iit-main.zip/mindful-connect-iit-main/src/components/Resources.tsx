
import { BookOpen, Clock, Award, Headphones, FileText, Film } from 'lucide-react';
import { Link } from 'react-router-dom';

const Resources = () => {
  const categories = [
    {
      icon: <Award className="h-6 w-6" />,
      title: "Productivity & Study Tips",
      description: "Effective techniques for time management and academic focus",
      color: "bg-mindblue-100 text-mindblue-600"
    },
    {
      icon: <Headphones className="h-6 w-6" />,
      title: "Meditation & Mindfulness",
      description: "Guided practices for stress reduction and mental clarity",
      color: "bg-mindpurple-100 text-mindpurple-600"
    },
    {
      icon: <Clock className="h-6 w-6" />,
      title: "Audio Therapy Sessions",
      description: "Relaxation recordings for anxiety and sleep improvement",
      color: "bg-mindteal-100 text-mindteal-600"
    },
    {
      icon: <Film className="h-6 w-6" />,
      title: "Webinars & Expert Talks",
      description: "Recordings from mental health professionals and experts",
      color: "bg-mindblue-100 text-mindblue-600"
    },
    {
      icon: <FileText className="h-6 w-6" />,
      title: "Self-Help Blogs",
      description: "Articles on managing academic pressure and mental wellbeing",
      color: "bg-mindpurple-100 text-mindpurple-600"
    },
    {
      icon: <BookOpen className="h-6 w-6" />,
      title: "Academic Resources",
      description: "Subject-specific guidance and exam preparation strategies",
      color: "bg-mindteal-100 text-mindteal-600"
    }
  ];

  // Sample featured resources
  const featuredResources = [
    {
      title: "Managing Exam Anxiety: A Student's Guide",
      category: "Self-Help",
      time: "10 min read",
      image: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
    },
    {
      title: "5-Minute Mindfulness for Busy Students",
      category: "Meditation",
      time: "5 min audio",
      image: "https://images.unsplash.com/photo-1506126613408-eca07ce68773?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1498&q=80"
    },
    {
      title: "Finding Balance: Academic and Personal Life",
      category: "Webinar",
      time: "45 min video",
      image: "https://images.unsplash.com/photo-1552581234-26160f608093?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900">Mental Health Resources</h2>
          <p className="mt-4 text-xl text-gray-600 max-w-2xl mx-auto">
            Explore our collection of resources designed to support your mental wellbeing
          </p>
        </div>
        
        {/* Resource Categories */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {categories.map((category, index) => (
            <div 
              key={index} 
              className="mindcard p-6 hover:translate-y-[-4px]"
            >
              <div className={`${category.color} p-3 inline-flex rounded-lg mb-4`}>
                {category.icon}
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{category.title}</h3>
              <p className="text-gray-600 mb-4">{category.description}</p>
              <Link 
                to={`/resources/${category.title.toLowerCase().replace(/ & /g, '-').replace(/ /g, '-')}`}
                className="text-mindblue-600 hover:text-mindblue-800 font-medium inline-flex items-center"
              >
                Explore Resources
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </Link>
            </div>
          ))}
        </div>
        
        {/* Featured Resources */}
        <div className="mb-12">
          <h3 className="text-2xl font-bold text-gray-900 mb-6">Featured Resources</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {featuredResources.map((resource, index) => (
              <div key={index} className="mindcard overflow-hidden group">
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={resource.image} 
                    alt={resource.title} 
                    className="w-full h-full object-cover transition-transform group-hover:scale-105"
                  />
                  <div className="absolute top-2 left-2 bg-white/80 backdrop-blur-sm rounded-full px-2 py-1">
                    <span className="text-xs font-medium text-gray-800">{resource.category}</span>
                  </div>
                  <div className="absolute bottom-2 right-2 bg-white/80 backdrop-blur-sm rounded-full px-2 py-1 flex items-center">
                    <Clock className="h-3 w-3 text-gray-600 mr-1" />
                    <span className="text-xs font-medium text-gray-800">{resource.time}</span>
                  </div>
                </div>
                <div className="p-4">
                  <h4 className="font-bold text-gray-900 hover:text-mindblue-600 transition-colors">
                    <Link to="/resources/resource-detail">{resource.title}</Link>
                  </h4>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="text-center">
          <Link to="/resources" className="btn-outline inline-flex items-center space-x-2">
            <span>Browse All Resources</span>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default Resources;
