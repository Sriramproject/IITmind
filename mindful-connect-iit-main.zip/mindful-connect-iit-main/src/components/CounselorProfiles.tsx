
import { useState } from 'react';
import { Star, Mail, Phone, MessageSquare } from 'lucide-react';
import { Link } from 'react-router-dom';

// Sample counselor data
const counselorsData = [
  {
    id: 1,
    name: "Dr. Priya Sharma",
    designation: "Clinical Psychologist",
    image: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80",
    email: "priya.sharma@iitm.ac.in",
    location: "Student Wellness Center, Block A",
    availability: "Mon-Fri: 10:00 AM - 4:00 PM",
    rating: 4.8,
    specialization: "Academic Stress"
  },
  {
    id: 2,
    name: "Dr. Arun Kumar",
    designation: "Mental Health Counselor",
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80",
    email: "arun.kumar@iitm.ac.in",
    location: "Online Only",
    availability: "Tue, Thu: 2:00 PM - 7:00 PM",
    rating: 4.7,
    specialization: "Relationship Issues"
  },
  {
    id: 3,
    name: "Dr. Shreya Patel",
    designation: "Wellness Coach",
    image: "https://images.unsplash.com/photo-1551836022-d5d88e9218df?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80",
    email: "shreya.patel@iitm.ac.in",
    location: "Student Health Center, Block C",
    availability: "Mon, Wed, Fri: 9:00 AM - 1:00 PM",
    rating: 4.9,
    specialization: "Health & Lifestyle"
  },
  {
    id: 4,
    name: "Dr. Rahul Verma",
    designation: "Academic Advisor",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    email: "rahul.verma@iitm.ac.in",
    location: "Academic Block, Room 204",
    availability: "Tue, Thu: 10:00 AM - 3:00 PM",
    rating: 4.6,
    specialization: "Mental Health Support"
  }
];

const CounselorProfiles = () => {
  // Randomly shuffle counselors each time component renders
  const [shuffledCounselors] = useState(() => {
    const shuffled = [...counselorsData];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  });

  return (
    <section className="py-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900">Our Expert Counselors</h2>
          <p className="mt-4 text-xl text-gray-600 max-w-2xl mx-auto">
            Meet our team of professional counselors dedicated to supporting your mental wellbeing
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {shuffledCounselors.map((counselor) => (
            <div key={counselor.id} className="mindcard overflow-hidden">
              <div className="relative">
                <img 
                  src={counselor.image} 
                  alt={counselor.name} 
                  className="w-full h-60 object-cover"
                />
                <div className="absolute top-2 right-2 bg-white/80 backdrop-blur-sm rounded-full px-2 py-1 flex items-center">
                  <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                  <span className="text-sm font-medium ml-1">{counselor.rating}</span>
                </div>
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent text-white p-4">
                  <div className="inline-block px-2 py-1 bg-mindpurple-600 rounded-full text-xs font-semibold mb-2">
                    {counselor.specialization}
                  </div>
                </div>
              </div>
              
              <div className="p-4 space-y-3">
                <div>
                  <h3 className="font-bold text-lg text-gray-900">{counselor.name}</h3>
                  <p className="text-gray-600 text-sm">{counselor.designation}</p>
                </div>
                
                <div className="text-sm text-gray-700">
                  <p className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-mindblue-600" />
                    {counselor.email}
                  </p>
                  <p className="mt-1 flex items-start gap-2">
                    <span className="mt-1"><Phone className="h-4 w-4 text-mindblue-600" /></span>
                    <span>
                      <span className="block">{counselor.location}</span>
                      <span className="block text-xs text-gray-500">{counselor.availability}</span>
                    </span>
                  </p>
                </div>
                
                <div className="pt-2 flex space-x-2">
                  <button className="btn-primary py-1.5 px-3 text-sm flex-1 flex items-center justify-center gap-1">
                    <Phone className="h-4 w-4" />
                    <span>Call</span>
                  </button>
                  <button className="btn-secondary py-1.5 px-3 text-sm flex-1 flex items-center justify-center gap-1">
                    <MessageSquare className="h-4 w-4" />
                    <span>Chat</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <Link to="/counselors" className="btn-outline inline-flex items-center space-x-2">
            <span>View All Counselors</span>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default CounselorProfiles;
