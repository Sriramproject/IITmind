
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const Hero = () => {
  return (
    <section className="relative py-12 md:py-20 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden -z-10">
        <div className="absolute top-12 right-0 w-56 h-56 bg-mindpurple-100 rounded-full blur-3xl opacity-30"></div>
        <div className="absolute bottom-12 left-0 w-64 h-64 bg-mindteal-100 rounded-full blur-3xl opacity-30"></div>
        <div className="absolute top-48 left-1/4 w-72 h-72 bg-mindblue-100 rounded-full blur-3xl opacity-30"></div>
      </div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center md:space-x-12">
          <div className="md:w-1/2 space-y-6 mb-10 md:mb-0">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight text-gray-900">
              Your Mental Wellbeing Matters at 
              <span className="text-transparent bg-clip-text mindgradient"> IIT Madras</span>
            </h1>
            <p className="text-lg text-gray-600 md:pr-8">
              A safe space for BS degree students to access mental health resources, 
              connect with counselors anonymously, and find support during your academic journey.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 pt-4">
              <Link to="/chat" className="btn-primary flex items-center justify-center space-x-2">
                <span>Chat Anonymously</span>
                <ArrowRight className="h-4 w-4" />
              </Link>
              <Link to="/counselors" className="btn-outline flex items-center justify-center space-x-2">
                <span>Meet Our Counselors</span>
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
          
          <div className="md:w-1/2 relative">
            <div className="relative rounded-2xl overflow-hidden shadow-xl animate-float">
              <div className="absolute inset-0 bg-gradient-to-br from-mindblue-50 to-mindpurple-50 opacity-75"></div>
              <img 
                src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1471&q=80" 
                alt="IIT Madras students" 
                className="relative w-full h-auto rounded-2xl mix-blend-overlay"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-white/70 to-transparent p-6">
                <div className="text-center">
                  <p className="text-gray-800 font-semibold text-lg">
                    Join 5000+ IIT Madras students who prioritize their mental health
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
