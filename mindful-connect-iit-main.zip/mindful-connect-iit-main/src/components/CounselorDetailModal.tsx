
import { X, Mail, Phone, MessageSquare, Clock, MapPin, Star, Award, BookOpen, Calendar } from 'lucide-react';
import { useEffect } from 'react';

interface Counselor {
  id: number;
  name: string;
  designation: string;
  image: string;
  email: string;
  location: string;
  room: string;
  availability: string;
  rating: number;
  specialization: string;
  bio: string;
  reviews: number;
  phone: string;
}

interface CounselorDetailModalProps {
  counselor: Counselor;
  onClose: () => void;
  onCall: () => void;
  onChat: () => void;
}

const CounselorDetailModal = ({ counselor, onClose, onCall, onChat }: CounselorDetailModalProps) => {
  useEffect(() => {
    // Prevent body scrolling when modal is open
    document.body.style.overflow = 'hidden';
    
    // Add escape key listener
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    
    window.addEventListener('keydown', handleEscape);
    
    return () => {
      document.body.style.overflow = 'unset';
      window.removeEventListener('keydown', handleEscape);
    };
  }, [onClose]);
  
  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-card rounded-xl shadow-lg w-full max-w-4xl h-[90vh] overflow-hidden flex flex-col">
        <div className="flex justify-between items-center p-4 border-b border-border">
          <h2 className="text-xl font-bold">Counselor Profile</h2>
          <button 
            onClick={onClose}
            className="p-1 rounded-full hover:bg-muted"
            aria-label="Close"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        
        <div className="flex-grow overflow-y-auto">
          <div className="md:flex">
            <div className="md:w-1/3 p-4">
              <div className="relative">
                <img 
                  src={counselor.image} 
                  alt={counselor.name} 
                  className="w-full rounded-lg object-cover aspect-[3/4]"
                />
                <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-sm rounded-full px-2 py-1 flex items-center">
                  <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                  <span className="text-sm font-medium ml-1 text-white">{counselor.rating}</span>
                  <span className="text-xs text-gray-300 ml-1">({counselor.reviews})</span>
                </div>
              </div>
              
              <div className="mt-4 space-y-3">
                <div className="bg-muted/50 rounded-lg p-3">
                  <h3 className="font-medium text-foreground/80 mb-1 flex items-center gap-1">
                    <MapPin className="h-4 w-4" /> Location
                  </h3>
                  <p className="text-sm">{counselor.location}</p>
                  <p className="text-sm mt-1">{counselor.room}</p>
                </div>
                
                <div className="bg-muted/50 rounded-lg p-3">
                  <h3 className="font-medium text-foreground/80 mb-1 flex items-center gap-1">
                    <Clock className="h-4 w-4" /> Availability
                  </h3>
                  <p className="text-sm">{counselor.availability}</p>
                </div>
                
                <div className="bg-muted/50 rounded-lg p-3">
                  <h3 className="font-medium text-foreground/80 mb-1 flex items-center gap-1">
                    <Mail className="h-4 w-4" /> Contact
                  </h3>
                  <p className="text-sm">{counselor.email}</p>
                  <p className="text-sm mt-1">{counselor.phone}</p>
                </div>
              </div>
            </div>
            
            <div className="md:w-2/3 p-4">
              <div className="mb-6">
                <h1 className="text-2xl font-bold text-foreground">{counselor.name}</h1>
                <p className="text-muted-foreground">{counselor.designation}</p>
                <div className="mt-2 inline-block px-3 py-1 bg-mindpurple-600 text-white rounded-full text-sm font-medium">
                  {counselor.specialization}
                </div>
              </div>
              
              <div className="space-y-4 mb-6">
                <div>
                  <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
                    <BookOpen className="h-5 w-5 text-mindblue-600" /> About
                  </h3>
                  <p className="text-foreground/80">{counselor.bio}</p>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
                    <Award className="h-5 w-5 text-mindblue-600" /> Expertise
                  </h3>
                  <ul className="list-disc list-inside text-foreground/80 pl-2 space-y-1">
                    <li>Specialized in {counselor.specialization.toLowerCase()}</li>
                    <li>One-on-one counseling sessions</li>
                    <li>Student wellness workshops</li>
                    <li>Crisis intervention</li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
                    <Calendar className="h-5 w-5 text-mindblue-600" /> Schedule
                  </h3>
                  <p className="text-foreground/80">
                    Available for scheduled appointments during {counselor.availability.toLowerCase()}.
                    Sessions typically last 45-60 minutes.
                  </p>
                </div>
              </div>
              
              <div className="bg-muted/30 rounded-lg p-4 text-sm">
                <p className="text-muted-foreground italic">
                  "I believe in creating a safe, non-judgmental space where students can freely express their concerns.
                  My approach is collaborative, focusing on practical solutions while addressing deeper emotional needs."
                </p>
                <p className="mt-2 text-right font-medium">— {counselor.name}</p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="p-4 border-t border-border flex justify-end gap-3">
          <button 
            onClick={onCall}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-mindblue-600 hover:bg-mindblue-700 text-white"
          >
            <Phone className="h-4 w-4" />
            <span>Call {counselor.name.split(' ')[0]}</span>
          </button>
          
          <button 
            onClick={onChat}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-mindpurple-600 hover:bg-mindpurple-700 text-white"
          >
            <MessageSquare className="h-4 w-4" />
            <span>Chat with {counselor.name.split(' ')[0]}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default CounselorDetailModal;
