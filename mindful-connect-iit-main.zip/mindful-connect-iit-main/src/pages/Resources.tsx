
import { useState } from 'react';
import { Search, BookOpen, Clock, Award, Headphones, FileText, Film, ChevronRight, Download } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';

// Resource categories with their icons
const resourceCategories = [
  {
    id: 'productivity',
    name: 'Productivity & Study Tips',
    icon: <Award className="h-6 w-6" />,
    color: 'bg-mindblue-100 text-mindblue-600'
  },
  {
    id: 'meditation',
    name: 'Meditation & Mindfulness',
    icon: <Headphones className="h-6 w-6" />,
    color: 'bg-mindpurple-100 text-mindpurple-600'
  },
  {
    id: 'audio',
    name: 'Audio Therapy Sessions',
    icon: <Clock className="h-6 w-6" />,
    color: 'bg-mindteal-100 text-mindteal-600'
  },
  {
    id: 'webinars',
    name: 'Webinars & Expert Talks',
    icon: <Film className="h-6 w-6" />,
    color: 'bg-mindblue-100 text-mindblue-600'
  },
  {
    id: 'blogs',
    name: 'Self-Help Blogs',
    icon: <FileText className="h-6 w-6" />,
    color: 'bg-mindpurple-100 text-mindpurple-600'
  },
  {
    id: 'academic',
    name: 'Academic Resources',
    icon: <BookOpen className="h-6 w-6" />,
    color: 'bg-mindteal-100 text-mindteal-600'
  }
];

// Sample resource data
const resourcesData = [
  {
    id: 1,
    title: "Managing Exam Anxiety: A Student's Guide",
    category: "blogs",
    categoryName: "Self-Help Blogs",
    type: "Article",
    time: "10 min read",
    image: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    description: "Learn effective strategies to manage anxiety before and during exams with research-backed techniques.",
    featured: true
  },
  {
    id: 2,
    title: "5-Minute Mindfulness for Busy Students",
    category: "meditation",
    categoryName: "Meditation & Mindfulness",
    type: "Audio",
    time: "5 min audio",
    image: "https://images.unsplash.com/photo-1506126613408-eca07ce68773?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1498&q=80",
    description: "Quick mindfulness exercises that fit into your busy schedule between classes and study sessions.",
    featured: true
  },
  {
    id: 3,
    title: "Finding Balance: Academic and Personal Life",
    category: "webinars",
    categoryName: "Webinars & Expert Talks",
    type: "Video",
    time: "45 min video",
    image: "https://images.unsplash.com/photo-1552581234-26160f608093?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    description: "A webinar by Prof. Ramesh discussing strategies to maintain a healthy balance while pursuing academic excellence.",
    featured: true
  },
  {
    id: 4,
    title: "Pomodoro Technique for Engineering Students",
    category: "productivity",
    categoryName: "Productivity & Study Tips",
    type: "Article",
    time: "7 min read",
    image: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    description: "Adapt the popular Pomodoro Technique to optimize your study sessions for technical subjects.",
    featured: false
  },
  {
    id: 5,
    title: "Calming Anxiety Before Presentations",
    category: "audio",
    categoryName: "Audio Therapy Sessions",
    type: "Audio",
    time: "12 min audio",
    image: "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    description: "Guided relaxation techniques to help calm nerves before class presentations or project defenses.",
    featured: false
  },
  {
    id: 6,
    title: "Imposter Syndrome in Higher Education",
    category: "blogs",
    categoryName: "Self-Help Blogs",
    type: "Article",
    time: "15 min read",
    image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    description: "Understand and overcome the feelings of inadequacy common among high-achieving students.",
    featured: false
  },
  {
    id: 7,
    title: "Building Resilience in Academic Settings",
    category: "webinars",
    categoryName: "Webinars & Expert Talks",
    type: "Video",
    time: "60 min video",
    image: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80",
    description: "Dr. Priya Sharma's talk on developing resilience strategies for managing academic setbacks.",
    featured: false
  },
  {
    id: 8,
    title: "Digital Note-Taking for STEM Subjects",
    category: "productivity",
    categoryName: "Productivity & Study Tips",
    type: "Article",
    time: "8 min read",
    image: "https://images.unsplash.com/photo-1501504905252-473c47e087f8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1074&q=80",
    description: "Effective digital note-taking techniques specifically designed for technical and mathematical subjects.",
    featured: false
  },
  {
    id: 9,
    title: "Deep Sleep for Better Learning",
    category: "audio",
    categoryName: "Audio Therapy Sessions",
    type: "Audio",
    time: "30 min audio",
    image: "https://images.unsplash.com/photo-1541781774459-bb2af2f05b55?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1460&q=80",
    description: "Guided meditation designed to improve sleep quality, enhancing memory consolidation and learning.",
    featured: false
  },
  {
    id: 10,
    title: "Understanding CS Course Prerequisites",
    category: "academic",
    categoryName: "Academic Resources",
    type: "Guide",
    time: "20 min read",
    image: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    description: "A comprehensive guide to understanding and preparing for Computer Science course prerequisites at IIT Madras.",
    featured: false
  },
  {
    id: 11,
    title: "Mental Health in Engineering Education",
    category: "webinars",
    categoryName: "Webinars & Expert Talks",
    type: "Video",
    time: "50 min video",
    image: "https://images.unsplash.com/photo-1543269865-cbf427effbad?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    description: "An expert panel discussion on mental health challenges specific to engineering students and coping strategies.",
    featured: false
  },
  {
    id: 12,
    title: "Gentle Morning Yoga for Focus",
    category: "meditation",
    categoryName: "Meditation & Mindfulness",
    type: "Video",
    time: "15 min video",
    image: "https://images.unsplash.com/photo-1593811167562-9cef47bfc4d7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1471&q=80",
    description: "A quick morning yoga routine designed to improve mental clarity and focus for a productive study day.",
    featured: false
  }
];

const ResourcesPage = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedType, setSelectedType] = useState<string | null>(null);
  
  // Filter resources based on search and filters
  const filteredResources = resourcesData.filter(resource => {
    const matchesSearch = resource.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         resource.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         resource.categoryName.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = selectedCategory === null || resource.category === selectedCategory;
    const matchesType = selectedType === null || resource.type === selectedType;
    
    return matchesSearch && matchesCategory && matchesType;
  });
  
  // Get featured resources
  const featuredResources = resourcesData.filter(resource => resource.featured);
  
  // Get unique resource types
  const resourceTypes = Array.from(new Set(resourcesData.map(resource => resource.type)));

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow bg-gray-50 py-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Mental Health Resources</h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Explore our collection of tools, guides, and materials designed to support your wellbeing
            </p>
          </div>
          
          {/* Search and Filters */}
          <div className="bg-white rounded-xl shadow-md p-4 mb-8">
            <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4">
              <div className="flex-grow">
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Search resources..."
                    className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-mindblue-500 focus:border-mindblue-500"
                  />
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
                <div className="min-w-[200px]">
                  <select
                    value={selectedCategory || ''}
                    onChange={(e) => setSelectedCategory(e.target.value || null)}
                    className="block w-full py-2 px-3 border border-gray-300 rounded-lg focus:ring-mindblue-500 focus:border-mindblue-500"
                  >
                    <option value="">All Categories</option>
                    {resourceCategories.map((category) => (
                      <option key={category.id} value={category.id}>{category.name}</option>
                    ))}
                  </select>
                </div>
                
                <div className="min-w-[200px]">
                  <select
                    value={selectedType || ''}
                    onChange={(e) => setSelectedType(e.target.value || null)}
                    className="block w-full py-2 px-3 border border-gray-300 rounded-lg focus:ring-mindblue-500 focus:border-mindblue-500"
                  >
                    <option value="">All Types</option>
                    {resourceTypes.map((type) => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          </div>
          
          {/* Featured Resources Section (only shown when no filters are active) */}
          {!searchTerm && !selectedCategory && !selectedType && (
            <div className="mb-12">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Featured Resources</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {featuredResources.map((resource) => (
                  <div key={resource.id} className="mindcard overflow-hidden group h-full flex flex-col">
                    <div className="relative h-48 overflow-hidden">
                      <img 
                        src={resource.image} 
                        alt={resource.title} 
                        className="w-full h-full object-cover transition-transform group-hover:scale-105"
                      />
                      <div className="absolute top-2 left-2 bg-white/80 backdrop-blur-sm rounded-full px-2 py-1">
                        <span className="text-xs font-medium text-gray-800">{resource.categoryName}</span>
                      </div>
                      <div className="absolute bottom-2 right-2 bg-white/80 backdrop-blur-sm rounded-full px-2 py-1 flex items-center">
                        <Clock className="h-3 w-3 text-gray-600 mr-1" />
                        <span className="text-xs font-medium text-gray-800">{resource.time}</span>
                      </div>
                    </div>
                    <div className="p-4 flex-grow">
                      <span className="inline-block px-2 py-1 bg-gray-100 rounded-full text-xs font-medium text-gray-800 mb-2">
                        {resource.type}
                      </span>
                      <h3 className="font-bold text-gray-900 hover:text-mindblue-600 transition-colors mb-2">
                        <a href={`/resources/${resource.id}`}>{resource.title}</a>
                      </h3>
                      <p className="text-gray-600 text-sm">{resource.description}</p>
                    </div>
                    <div className="p-4 pt-0">
                      <a 
                        href={`/resources/${resource.id}`}
                        className="text-mindblue-600 hover:text-mindblue-800 font-medium text-sm inline-flex items-center"
                      >
                        View Resource
                        <ChevronRight className="h-4 w-4 ml-1" />
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* Resource Categories (only shown when no filters are active) */}
          {!searchTerm && !selectedCategory && !selectedType && (
            <div className="mb-12">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Resource Categories</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {resourceCategories.map((category) => (
                  <div 
                    key={category.id} 
                    className="mindcard p-6 hover:translate-y-[-4px] cursor-pointer"
                    onClick={() => setSelectedCategory(category.id)}
                  >
                    <div className={`${category.color} p-3 inline-flex rounded-lg mb-4`}>
                      {category.icon}
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{category.name}</h3>
                    <p className="text-gray-600 mb-4">
                      {category.id === 'productivity' && "Effective techniques for time management and academic focus"}
                      {category.id === 'meditation' && "Guided practices for stress reduction and mental clarity"}
                      {category.id === 'audio' && "Relaxation recordings for anxiety and sleep improvement"}
                      {category.id === 'webinars' && "Recordings from mental health professionals and experts"}
                      {category.id === 'blogs' && "Articles on managing academic pressure and mental wellbeing"}
                      {category.id === 'academic' && "Subject-specific guidance and exam preparation strategies"}
                    </p>
                    <button 
                      onClick={() => setSelectedCategory(category.id)}
                      className="text-mindblue-600 hover:text-mindblue-800 font-medium inline-flex items-center"
                    >
                      Explore Resources
                      <ChevronRight className="h-4 w-4 ml-1" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* Filtered Resources Results */}
          {(searchTerm || selectedCategory || selectedType) && (
            <>
              <div className="mb-6">
                <h2 className="text-2xl font-bold text-gray-900">
                  {selectedCategory ? 
                    `${resourceCategories.find(c => c.id === selectedCategory)?.name} Resources` : 
                    'All Resources'}
                </h2>
                <p className="text-gray-600 mt-1">
                  Showing {filteredResources.length} resources
                  {selectedType ? ` of type "${selectedType}"` : ''}
                  {searchTerm ? ` matching "${searchTerm}"` : ''}
                </p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredResources.map((resource) => (
                  <div key={resource.id} className="mindcard overflow-hidden group h-full flex flex-col">
                    <div className="relative h-48 overflow-hidden">
                      <img 
                        src={resource.image} 
                        alt={resource.title} 
                        className="w-full h-full object-cover transition-transform group-hover:scale-105"
                      />
                      <div className="absolute top-2 left-2 bg-white/80 backdrop-blur-sm rounded-full px-2 py-1">
                        <span className="text-xs font-medium text-gray-800">{resource.categoryName}</span>
                      </div>
                      <div className="absolute bottom-2 right-2 bg-white/80 backdrop-blur-sm rounded-full px-2 py-1 flex items-center">
                        <Clock className="h-3 w-3 text-gray-600 mr-1" />
                        <span className="text-xs font-medium text-gray-800">{resource.time}</span>
                      </div>
                    </div>
                    <div className="p-4 flex-grow">
                      <span className="inline-block px-2 py-1 bg-gray-100 rounded-full text-xs font-medium text-gray-800 mb-2">
                        {resource.type}
                      </span>
                      <h3 className="font-bold text-gray-900 hover:text-mindblue-600 transition-colors mb-2">
                        <a href={`/resources/${resource.id}`}>{resource.title}</a>
                      </h3>
                      <p className="text-gray-600 text-sm">{resource.description}</p>
                    </div>
                    <div className="p-4 pt-0">
                      <a 
                        href={`/resources/${resource.id}`}
                        className="text-mindblue-600 hover:text-mindblue-800 font-medium text-sm inline-flex items-center"
                      >
                        {resource.type === 'Article' || resource.type === 'Guide' ? 'Read Now' : 
                         resource.type === 'Audio' ? 'Listen Now' : 'Watch Now'}
                        <ChevronRight className="h-4 w-4 ml-1" />
                      </a>
                    </div>
                  </div>
                ))}
              </div>
              
              {/* Empty State */}
              {filteredResources.length === 0 && (
                <div className="text-center py-16 bg-white rounded-xl shadow-sm">
                  <div className="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                    <Search className="h-8 w-8 text-gray-400" />
                  </div>
                  <h2 className="text-lg font-medium text-gray-900 mb-1">No resources found</h2>
                  <p className="text-gray-600 mb-4">Try adjusting your search or filter criteria</p>
                  <button 
                    onClick={() => {
                      setSearchTerm('');
                      setSelectedCategory(null);
                      setSelectedType(null);
                    }}
                    className="btn-outline"
                  >
                    Clear all filters
                  </button>
                </div>
              )}
            </>
          )}
          
          {/* Download Resources */}
          <div className="mt-16 bg-mindblue-50 rounded-xl overflow-hidden">
            <div className="flex flex-col md:flex-row">
              <div className="md:w-1/2 p-8 flex flex-col justify-center">
                <h2 className="text-2xl font-bold text-gray-900 mb-4">
                  Download Resources for Offline Use
                </h2>
                <p className="text-gray-700 mb-6">
                  Access our mental health guides, worksheets, and exercises offline. 
                  Perfect for times when you need support but don't have internet access.
                </p>
                <div className="space-y-4">
                  <div className="flex items-center">
                    <button className="btn-primary flex items-center">
                      <Download className="h-4 w-4 mr-2" />
                      <span>Mental Health Self-Assessment Kit</span>
                    </button>
                  </div>
                  <div className="flex items-center">
                    <button className="btn-outline flex items-center">
                      <Download className="h-4 w-4 mr-2" />
                      <span>Stress Management Workbook</span>
                    </button>
                  </div>
                  <div className="flex items-center">
                    <button className="btn-outline flex items-center">
                      <Download className="h-4 w-4 mr-2" />
                      <span>IIT Mind Mobile App</span>
                    </button>
                  </div>
                </div>
              </div>
              <div className="md:w-1/2 relative">
                <img 
                  src="https://images.unsplash.com/photo-1551836022-d5d88e9218df?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80" 
                  alt="Download resources" 
                  className="w-full h-full object-cover object-center"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-mindblue-500/20 to-transparent"></div>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default ResourcesPage;
