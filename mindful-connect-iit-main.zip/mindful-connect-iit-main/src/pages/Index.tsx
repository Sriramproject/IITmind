
import { useState } from 'react';
import Header from '../components/Header';
import Hero from '../components/Hero';
import Features from '../components/Features';
import CounselorProfiles from '../components/CounselorProfiles';
import ChatbotPreview from '../components/ChatbotPreview';
import Resources from '../components/Resources';
import Testimonials from '../components/Testimonials';
import Footer from '../components/Footer';
import AuthModal from '../components/AuthModal';

const Index = () => {
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow">
        <Hero />
        <Features />
        <CounselorProfiles />
        <ChatbotPreview />
        <Testimonials />
        <Resources />
      </main>
      <Footer />
      <AuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} />
    </div>
  );
};

export default Index;
