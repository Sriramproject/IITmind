
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useAuth } from '../context/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Textarea } from '@/components/ui/textarea';
import { MessageSquare, Search, Clock, User, Plus, X, Bot, Paperclip, Send } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

const Chat = () => {
  const { user } = useAuth();
  const [counselors, setCounselors] = useState<any[]>([]);
  const [chats, setChats] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [showNewChat, setShowNewChat] = useState(false);
  const [selectedCounselor, setSelectedCounselor] = useState<string | null>(null);
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [isCreatingChat, setIsCreatingChat] = useState(false);
  const [showAIChat, setShowAIChat] = useState(false);
  const [aiMessage, setAIMessage] = useState('');
  const [aiConversation, setAIConversation] = useState<any[]>([]);
  const [isSendingAI, setIsSendingAI] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        
        // Fetch all counselors
        const { data: counselorsData, error: counselorsError } = await supabase
          .from('counselors')
          .select('*')
          .eq('is_active', true);
          
        if (counselorsError) throw counselorsError;
        setCounselors(counselorsData);
        
        // Fetch user's chats
        if (user) {
          const { data: chatsData, error: chatsError } = await supabase
            .from('chats')
            .select(`
              id,
              counselor_id,
              status,
              created_at,
              updated_at,
              messages:messages(
                id,
                message_text,
                sender_type,
                created_at
              )
            `)
            .eq('student_id', user.id)
            .order('updated_at', { ascending: false });
            
          if (chatsError) throw chatsError;
          
          // Process the chat data to include latest message
          const processedChats = chatsData.map(chat => {
            const messages = chat.messages || [];
            messages.sort((a: any, b: any) => 
              new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
            );
            
            return {
              ...chat,
              latest_message: messages.length > 0 ? messages[0] : null,
              message_count: messages.length,
              counselor: counselorsData.find(c => c.id === chat.counselor_id)
            };
          });
          
          setChats(processedChats);
        }
      } catch (error: any) {
        console.error('Error fetching data:', error);
        toast({
          title: 'Error',
          description: 'Failed to load chat data.',
          variant: 'destructive'
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, [user, toast]);

  // Initialize AI conversation with a welcome message
  useEffect(() => {
    if (showAIChat && aiConversation.length === 0) {
      setAIConversation([
        {
          id: 'welcome',
          sender: 'ai',
          message: "Hi there! I'm your IIT Mind Assistant. I'm here to provide immediate support while you wait to connect with a counselor. How can I help you today?",
          timestamp: new Date().toISOString(),
        },
        {
          id: 'welcome-options',
          sender: 'ai',
          message: "You can ask me about:\n• Stress management techniques\n• Academic pressure\n• Self-care strategies\n• Resources available at IIT Madras\n\nOr if you'd prefer to speak with a human counselor directly, let me know!",
          timestamp: new Date().toISOString(),
        }
      ]);
    }
  }, [showAIChat, aiConversation.length]);
  
  const createNewChat = async () => {
    if (!user || !selectedCounselor) return;
    
    try {
      setIsCreatingChat(true);
      
      // Check if an active chat already exists with this counselor
      const existingChat = chats.find(
        chat => chat.counselor_id === selectedCounselor && chat.status === 'active'
      );
      
      if (existingChat) {
        // Navigate to existing chat
        navigate(`/chat/${existingChat.id}`);
        return;
      }
      
      // Create a new chat
      const { data, error } = await supabase
        .from('chats')
        .insert({
          student_id: user.id,
          counselor_id: selectedCounselor,
          is_anonymous: isAnonymous,
        })
        .select()
        .single();
        
      if (error) throw error;
      
      toast({
        title: 'Chat created',
        description: 'Your conversation has been started.',
      });
      
      // Navigate to the new chat
      navigate(`/chat/${data.id}`);
    } catch (error: any) {
      console.error('Error creating chat:', error);
      toast({
        title: 'Error',
        description: 'Failed to create a new chat.',
        variant: 'destructive'
      });
    } finally {
      setIsCreatingChat(false);
    }
  };

  const handleSendAIMessage = async () => {
    if (!aiMessage.trim()) return;

    // Add user message to conversation
    const userMessage = {
      id: Date.now().toString(),
      sender: 'user',
      message: aiMessage,
      timestamp: new Date().toISOString(),
    };
    
    setAIConversation(prev => [...prev, userMessage]);
    setAIMessage('');
    setIsSendingAI(true);

    try {
      // Call Gemini API through Supabase Edge Function
      const { data, error } = await supabase.functions.invoke('gemini-chat', {
        body: { prompt: aiMessage },
      });

      if (error) throw error;

      // Add AI response to conversation
      const aiResponse = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        message: data.message || "I'm sorry, I couldn't process that request. Please try again.",
        timestamp: new Date().toISOString(),
      };
      
      setAIConversation(prev => [...prev, aiResponse]);
    } catch (error) {
      console.error('Error calling Gemini API:', error);
      
      // Add error message to conversation
      const errorResponse = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        message: "I'm sorry, I'm having trouble connecting to my knowledge base right now. Please try again later or consider speaking with a human counselor.",
        timestamp: new Date().toISOString(),
      };
      
      setAIConversation(prev => [...prev, errorResponse]);
      
      toast({
        title: 'Error',
        description: 'Failed to get a response from the AI assistant.',
        variant: 'destructive'
      });
    } finally {
      setIsSendingAI(false);
    }
  };
  
  const filteredCounselors = counselors.filter(counselor => 
    counselor.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    counselor.specialization.toLowerCase().includes(searchQuery.toLowerCase()) ||
    counselor.role.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const getInitials = (name: string) => {
    if (!name) return 'C';
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  // Predefined questions for the AI chatbot
  const predefinedQuestions = [
    "I'm feeling overwhelmed with my coursework",
    "How can I manage exam anxiety?",
    "I'm having trouble sleeping due to stress",
    "I need help with time management",
    "I'm feeling isolated and lonely"
  ];
  
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      
      <main className="flex-grow container px-4 py-6 mx-auto">
        <div className="max-w-screen-xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-3xl font-bold text-foreground">Chat Support</h1>
            {!showNewChat && !showAIChat && (
              <div className="space-x-2">
                <Button 
                  variant="outline"
                  onClick={() => setShowAIChat(true)}
                  className="gap-2"
                >
                  <Bot className="h-4 w-4" />
                  AI Assistant
                </Button>
                <Button 
                  onClick={() => setShowNewChat(true)}
                  className="gap-2"
                >
                  <Plus className="h-4 w-4" />
                  New Conversation
                </Button>
              </div>
            )}
          </div>
          
          {showAIChat ? (
            <Card className="mb-8">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div className="flex items-center space-x-3">
                  <Avatar className="h-10 w-10">
                    <AvatarFallback className="bg-purple-100 text-purple-800">AI</AvatarFallback>
                  </Avatar>
                  <div>
                    <CardTitle>AI Assistant</CardTitle>
                    <CardDescription>First aid mental health support</CardDescription>
                  </div>
                </div>
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => setShowAIChat(false)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </CardHeader>
              <CardContent className="pt-4">
                <ScrollArea className="h-[400px] pr-4 mb-4">
                  <div className="space-y-4">
                    {aiConversation.map((msg) => (
                      <div 
                        key={msg.id} 
                        className={`flex ${
                          msg.sender === 'user' ? 'justify-end' : 'justify-start'
                        }`}
                      >
                        <div className="flex items-start max-w-[80%]">
                          {msg.sender === 'ai' && (
                            <Avatar className="h-8 w-8 mr-2 mt-1 flex-shrink-0">
                              <AvatarFallback className="bg-purple-100 text-purple-800 text-xs">AI</AvatarFallback>
                            </Avatar>
                          )}
                          
                          <div 
                            className={`px-4 py-3 rounded-lg ${
                              msg.sender === 'user'
                                ? 'bg-mindblue-500 text-white'
                                : 'bg-purple-100 dark:bg-purple-900/30 text-foreground'
                            }`}
                          >
                            <div className="whitespace-pre-line">{msg.message}</div>
                          </div>
                        </div>
                      </div>
                    ))}
                    {isSendingAI && (
                      <div className="flex justify-start">
                        <div className="flex items-start max-w-[80%]">
                          <Avatar className="h-8 w-8 mr-2 mt-1 flex-shrink-0">
                            <AvatarFallback className="bg-purple-100 text-purple-800 text-xs">AI</AvatarFallback>
                          </Avatar>
                          <div className="px-4 py-3 rounded-lg bg-purple-100 dark:bg-purple-900/30">
                            <div className="flex space-x-1">
                              <div className="h-2 w-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0s' }}></div>
                              <div className="h-2 w-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                              <div className="h-2 w-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </ScrollArea>
                
                {/* Predefined questions */}
                {aiConversation.length <= 3 && (
                  <div className="mb-4">
                    <p className="text-sm text-muted-foreground mb-2">Frequently asked questions:</p>
                    <div className="flex flex-wrap gap-2">
                      {predefinedQuestions.map((question, index) => (
                        <button
                          key={index}
                          className="text-xs bg-muted/50 hover:bg-muted px-3 py-1.5 rounded-full text-muted-foreground hover:text-foreground transition-colors"
                          onClick={() => {
                            setAIMessage(question);
                          }}
                        >
                          {question}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                
                <div className="border-t pt-4">
                  <div className="flex flex-col space-y-2">
                    <div className="relative">
                      <Textarea
                        value={aiMessage}
                        onChange={(e) => setAIMessage(e.target.value)}
                        placeholder="Type your message..."
                        className="min-h-[80px] pr-12"
                        disabled={isSendingAI}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            handleSendAIMessage();
                          }
                        }}
                      />
                      <div className="absolute bottom-2 right-2 flex items-center space-x-1">
                        <Button
                          type="button"
                          size="icon"
                          variant="ghost"
                          className="h-8 w-8 rounded-full"
                          title="Attach file (coming soon)"
                        >
                          <Paperclip className="h-4 w-4 text-muted-foreground" />
                        </Button>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <Button 
                        variant="outline" 
                        onClick={() => {
                          setShowAIChat(false);
                          setShowNewChat(true);
                        }}
                      >
                        Connect with Human Counselor
                      </Button>
                      <Button 
                        onClick={handleSendAIMessage}
                        disabled={!aiMessage.trim() || isSendingAI}
                      >
                        {isSendingAI ? (
                          <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                        ) : (
                          <>
                            Send
                            <Send className="ml-2 h-4 w-4" />
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : showNewChat ? (
            <Card className="mb-8">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div>
                  <CardTitle>Start a New Conversation</CardTitle>
                  <CardDescription>Choose a counselor to chat with</CardDescription>
                </div>
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => setShowNewChat(false)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </CardHeader>
              <CardContent className="pt-4">
                <div className="mb-4 relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search by name or specialization..."
                    className="pl-9"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                
                {filteredCounselors.length === 0 ? (
                  <div className="text-center py-8">
                    <User className="h-10 w-10 text-muted-foreground/50 mx-auto mb-2" />
                    <h3 className="text-lg font-medium">No counselors found</h3>
                    <p className="text-muted-foreground text-sm mt-1">Try a different search term</p>
                  </div>
                ) : (
                  <ScrollArea className="h-[400px] pr-4">
                    <div className="grid gap-4 md:grid-cols-2">
                      {filteredCounselors.map((counselor) => (
                        <div
                          key={counselor.id}
                          className={`border rounded-lg p-4 cursor-pointer transition-colors ${
                            selectedCounselor === counselor.id 
                              ? 'border-mindblue-500 bg-mindblue-50 dark:bg-mindblue-950/30' 
                              : 'hover:border-mindblue-300 hover:bg-mindblue-50/50 dark:hover:bg-mindblue-950/10'
                          }`}
                          onClick={() => setSelectedCounselor(counselor.id)}
                        >
                          <div className="flex items-start space-x-4">
                            <Avatar className="h-12 w-12">
                              <AvatarImage src={counselor.avatar_url} />
                              <AvatarFallback className="bg-mindblue-100 text-mindblue-800">
                                {getInitials(counselor.name)}
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <h3 className="font-medium">{counselor.name}</h3>
                              <p className="text-sm text-muted-foreground">{counselor.role}</p>
                              <div className="mt-2">
                                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-800/20 dark:text-blue-400">
                                  {counselor.specialization}
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                )}
              </CardContent>
              <CardFooter className="flex flex-col space-y-4">
                <div className="flex items-center space-x-2 w-full">
                  <input
                    type="checkbox"
                    id="anonymous"
                    checked={isAnonymous}
                    onChange={(e) => setIsAnonymous(e.target.checked)}
                    className="rounded text-mindblue-600 focus:ring-mindblue-500"
                  />
                  <label htmlFor="anonymous" className="text-sm">
                    Chat anonymously (counselor won't see your name)
                  </label>
                </div>
                <div className="flex justify-end w-full">
                  <Button
                    variant="outline"
                    className="mr-2"
                    onClick={() => setShowNewChat(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={createNewChat}
                    disabled={!selectedCounselor || isCreatingChat}
                  >
                    {isCreatingChat ? (
                      <>
                        <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Starting Chat...
                      </>
                    ) : (
                      'Start Conversation'
                    )}
                  </Button>
                </div>
              </CardFooter>
            </Card>
          ) : (
            <Tabs defaultValue="active" className="mb-8">
              <TabsList className="mb-4">
                <TabsTrigger value="active">Active Chats</TabsTrigger>
                <TabsTrigger value="ai">AI Assistant</TabsTrigger>
                <TabsTrigger value="all">All Conversations</TabsTrigger>
              </TabsList>
              
              <TabsContent value="active">
                {isLoading ? (
                  <div className="flex justify-center py-16">
                    <svg className="animate-spin h-12 w-12 text-mindblue-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                  </div>
                ) : (
                  <>
                    {chats.filter(chat => chat.status === 'active').length === 0 ? (
                      <div className="text-center py-16 bg-muted/30 rounded-lg border border-dashed">
                        <MessageSquare className="h-16 w-16 text-muted-foreground/50 mx-auto mb-4" />
                        <h3 className="text-xl font-medium">No active conversations</h3>
                        <p className="text-muted-foreground mt-2 max-w-md mx-auto">
                          Start a chat with one of our counselors to get support with your concerns.
                        </p>
                        <div className="mt-6 space-x-4">
                          <Button 
                            variant="outline"
                            onClick={() => setShowAIChat(true)}
                          >
                            <Bot className="mr-2 h-4 w-4" />
                            Talk to AI Assistant
                          </Button>
                          <Button 
                            onClick={() => setShowNewChat(true)}
                          >
                            <Plus className="mr-2 h-4 w-4" />
                            Start a Conversation
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                        {chats
                          .filter(chat => chat.status === 'active')
                          .map((chat) => (
                            <Card 
                              key={chat.id}
                              className="cursor-pointer hover:shadow-md transition-shadow"
                              onClick={() => navigate(`/chat/${chat.id}`)}
                            >
                              <CardHeader className="pb-2">
                                <div className="flex justify-between items-start">
                                  <div className="flex items-center space-x-2">
                                    <Avatar>
                                      <AvatarImage src={chat.counselor?.avatar_url} />
                                      <AvatarFallback className="bg-mindblue-100 text-mindblue-800">
                                        {getInitials(chat.counselor?.name || 'Counselor')}
                                      </AvatarFallback>
                                    </Avatar>
                                    <div>
                                      <CardTitle className="text-base">{chat.counselor?.name || 'Counselor'}</CardTitle>
                                      <CardDescription className="text-xs">{chat.counselor?.role || 'Counselor'}</CardDescription>
                                    </div>
                                  </div>
                                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-800/20 dark:text-green-400">
                                    Active
                                  </span>
                                </div>
                              </CardHeader>
                              <CardContent>
                                <div className="space-y-2">
                                  <p className="text-sm text-muted-foreground line-clamp-2">
                                    {chat.latest_message ? (
                                      `${chat.latest_message.sender_type === 'student' ? 'You: ' : ''}${chat.latest_message.message_text}`
                                    ) : 'No messages yet'}
                                  </p>
                                  <div className="flex items-center justify-between">
                                    <span className="flex items-center text-xs text-muted-foreground">
                                      <Clock className="h-3 w-3 mr-1" />
                                      {formatDistanceToNow(new Date(chat.updated_at), { addSuffix: true })}
                                    </span>
                                    <span className="text-xs font-medium">
                                      {chat.message_count} {chat.message_count === 1 ? 'message' : 'messages'}
                                    </span>
                                  </div>
                                </div>
                              </CardContent>
                              <CardFooter>
                                <Button className="w-full" variant="outline">
                                  Continue Conversation
                                </Button>
                              </CardFooter>
                            </Card>
                          ))}
                      </div>
                    )}
                  </>
                )}
              </TabsContent>
              
              <TabsContent value="ai">
                <div className="text-center py-16 bg-purple-50 dark:bg-purple-950/10 rounded-lg border border-dashed border-purple-200 dark:border-purple-800/30">
                  <Bot className="h-16 w-16 text-purple-500/70 mx-auto mb-4" />
                  <h3 className="text-xl font-medium">AI First Aid Assistant</h3>
                  <p className="text-muted-foreground mt-2 max-w-md mx-auto">
                    Get immediate support from our AI assistant before connecting with a human counselor.
                  </p>
                  <div className="flex justify-center mt-6">
                    <Button 
                      onClick={() => setShowAIChat(true)}
                      className="bg-purple-600 hover:bg-purple-700"
                    >
                      <Bot className="mr-2 h-4 w-4" />
                      Start AI Conversation
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground mt-4 max-w-md mx-auto">
                    Our AI assistant can help with stress management, academic pressure, and connecting you with the right resources.
                  </p>
                </div>
              </TabsContent>
              
              <TabsContent value="all">
                {isLoading ? (
                  <div className="flex justify-center py-16">
                    <svg className="animate-spin h-12 w-12 text-mindblue-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                  </div>
                ) : (
                  <>
                    {chats.length === 0 ? (
                      <div className="text-center py-16 bg-muted/30 rounded-lg border border-dashed">
                        <MessageSquare className="h-16 w-16 text-muted-foreground/50 mx-auto mb-4" />
                        <h3 className="text-xl font-medium">No conversations yet</h3>
                        <p className="text-muted-foreground mt-2 max-w-md mx-auto">
                          Start a chat with one of our counselors to get support with your concerns.
                        </p>
                        <div className="mt-6 space-x-4">
                          <Button 
                            variant="outline"
                            onClick={() => setShowAIChat(true)}
                          >
                            <Bot className="mr-2 h-4 w-4" />
                            Talk to AI Assistant
                          </Button>
                          <Button 
                            onClick={() => setShowNewChat(true)}
                          >
                            <Plus className="mr-2 h-4 w-4" />
                            Start a Conversation
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {chats.map((chat) => (
                          <Card 
                            key={chat.id}
                            className="cursor-pointer hover:shadow-md transition-shadow overflow-hidden"
                            onClick={() => navigate(`/chat/${chat.id}`)}
                          >
                            <div className="flex flex-col md:flex-row">
                              <div className="p-4 md:p-6 flex items-start space-x-4 flex-1">
                                <Avatar className="h-10 w-10">
                                  <AvatarImage src={chat.counselor?.avatar_url} />
                                  <AvatarFallback className="bg-mindblue-100 text-mindblue-800">
                                    {getInitials(chat.counselor?.name || 'Counselor')}
                                  </AvatarFallback>
                                </Avatar>
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center justify-between">
                                    <h3 className="font-medium truncate">{chat.counselor?.name || 'Counselor'}</h3>
                                    <div className="flex items-center space-x-2 ml-2">
                                      {chat.status === 'active' && (
                                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-800/20 dark:text-green-400 whitespace-nowrap">
                                          Active
                                        </span>
                                      )}
                                      <span className="text-xs text-muted-foreground whitespace-nowrap">
                                        {formatDistanceToNow(new Date(chat.updated_at), { addSuffix: true })}
                                      </span>
                                    </div>
                                  </div>
                                  <p className="text-sm text-muted-foreground truncate">
                                    {chat.counselor?.role || 'Counselor'} • {chat.counselor?.specialization || 'General'}
                                  </p>
                                  <p className="text-sm mt-2 line-clamp-2">
                                    {chat.latest_message ? (
                                      `${chat.latest_message.sender_type === 'student' ? 'You: ' : ''}${chat.latest_message.message_text}`
                                    ) : 'No messages yet'}
                                  </p>
                                  <div className="mt-2 text-xs">
                                    {chat.message_count} {chat.message_count === 1 ? 'message' : 'messages'}
                                  </div>
                                </div>
                              </div>
                              <div className="border-t md:border-t-0 md:border-l border-border p-3 md:px-6 md:py-6 flex md:flex-col justify-between items-center md:items-stretch">
                                <div className="text-xs text-muted-foreground">
                                  Started {new Date(chat.created_at).toLocaleDateString()}
                                </div>
                                <Button variant="outline" className="text-xs md:mt-4 whitespace-nowrap">
                                  View Chat
                                </Button>
                              </div>
                            </div>
                          </Card>
                        ))}
                      </div>
                    )}
                  </>
                )}
              </TabsContent>
            </Tabs>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Chat;
