
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useAuth } from '../context/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { MessageSquare, User, Key, LogOut, Save, Loader2, Clock } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

const Profile = () => {
  const { user, profile, signOut, refreshProfile } = useAuth();
  const [isLoading, setIsLoading] = useState(true);
  const [isUpdating, setIsUpdating] = useState(false);
  const [fullName, setFullName] = useState('');
  const [recentChats, setRecentChats] = useState<any[]>([]);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    if (profile) {
      setFullName(profile.full_name || '');
    }
  }, [profile]);

  useEffect(() => {
    const fetchRecentChats = async () => {
      if (!user) return;
      
      try {
        setIsLoading(true);
        
        // Fetch user's recent chats
        const { data: chatsData, error: chatsError } = await supabase
          .from('chats')
          .select(`
            id,
            counselor_id,
            status,
            created_at,
            updated_at,
            messages:messages(
              id,
              message_text,
              sender_type,
              created_at
            )
          `)
          .eq('student_id', user.id)
          .order('updated_at', { ascending: false })
          .limit(5);
          
        if (chatsError) throw chatsError;
        
        // Fetch counselor details for each chat
        if (chatsData && chatsData.length > 0) {
          const counselorIds = chatsData.map(chat => chat.counselor_id);
          
          const { data: counselorsData, error: counselorsError } = await supabase
            .from('counselors')
            .select('*')
            .in('id', counselorIds);
            
          if (counselorsError) throw counselorsError;
          
          // Process the chat data to include latest message and counselor details
          const processedChats = chatsData.map(chat => {
            const messages = chat.messages || [];
            messages.sort((a: any, b: any) => 
              new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
            );
            
            return {
              ...chat,
              latest_message: messages.length > 0 ? messages[0] : null,
              message_count: messages.length,
              counselor: counselorsData.find((c: any) => c.id === chat.counselor_id)
            };
          });
          
          setRecentChats(processedChats);
        }
      } catch (error: any) {
        console.error('Error fetching recent chats:', error);
        toast({
          title: 'Error',
          description: 'Failed to load recent chats.',
          variant: 'destructive'
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchRecentChats();
  }, [user, toast]);

  const handleUpdateProfile = async () => {
    if (!user) return;
    
    try {
      setIsUpdating(true);
      
      const { error } = await supabase
        .from('profiles')
        .update({ full_name: fullName })
        .eq('id', user.id);
        
      if (error) throw error;
      
      await refreshProfile();
      
      toast({
        title: 'Profile updated',
        description: 'Your profile has been updated successfully.',
      });
    } catch (error: any) {
      console.error('Error updating profile:', error);
      toast({
        title: 'Error',
        description: 'Failed to update profile.',
        variant: 'destructive'
      });
    } finally {
      setIsUpdating(false);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut();
      navigate('/');
    } catch (error: any) {
      console.error('Error signing out:', error);
      toast({
        title: 'Error',
        description: 'Failed to sign out.',
        variant: 'destructive'
      });
    }
  };

  const getInitials = (name: string) => {
    if (!name) return 'U';
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-6">
        <div className="max-w-5xl mx-auto">
          <h1 className="text-3xl font-bold mb-6">Your Profile</h1>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Profile Sidebar */}
            <div className="md:col-span-1">
              <Card className="mb-6">
                <CardHeader className="pb-2">
                  <CardTitle>Account</CardTitle>
                  <CardDescription>Manage your account information</CardDescription>
                </CardHeader>
                <CardContent className="flex flex-col items-center pt-4 pb-6">
                  <Avatar className="h-24 w-24 mb-4">
                    <AvatarImage src={profile?.avatar_url || ''} />
                    <AvatarFallback className="text-xl bg-mindblue-100 text-mindblue-800">
                      {getInitials(profile?.full_name || user?.email || 'User')}
                    </AvatarFallback>
                  </Avatar>
                  <h3 className="text-lg font-medium">{profile?.full_name || 'User'}</h3>
                  <p className="text-sm text-muted-foreground">{user?.email}</p>
                </CardContent>
                <CardFooter className="flex flex-col gap-2">
                  <Button 
                    variant="outline" 
                    className="w-full justify-start" 
                    onClick={() => {
                      document.getElementById('profile-tab-trigger')?.setAttribute('data-state', 'active');
                      document.getElementById('profile-tab')?.setAttribute('data-state', 'active');
                      document.getElementById('chats-tab')?.setAttribute('data-state', 'inactive');
                    }}
                  >
                    <User className="mr-2 h-4 w-4" />
                    Profile Settings
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full justify-start" 
                    onClick={() => {
                      document.getElementById('chats-tab-trigger')?.setAttribute('data-state', 'active');
                      document.getElementById('chats-tab')?.setAttribute('data-state', 'active');
                      document.getElementById('profile-tab')?.setAttribute('data-state', 'inactive');
                    }}
                  >
                    <MessageSquare className="mr-2 h-4 w-4" />
                    Recent Chats
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    onClick={handleLogout}
                  >
                    <LogOut className="mr-2 h-4 w-4" />
                    Sign Out
                  </Button>
                </CardFooter>
              </Card>
            </div>
            
            {/* Main Content */}
            <div className="md:col-span-2">
              <Tabs defaultValue="profile">
                <TabsList className="mb-4">
                  <TabsTrigger value="profile" id="profile-tab-trigger">Profile</TabsTrigger>
                  <TabsTrigger value="chats" id="chats-tab-trigger">Recent Chats</TabsTrigger>
                </TabsList>
                
                <TabsContent value="profile" id="profile-tab">
                  <Card>
                    <CardHeader>
                      <CardTitle>Profile Information</CardTitle>
                      <CardDescription>Update your personal information</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input id="email" value={user?.email || ''} disabled />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="name">Full Name</Label>
                        <Input 
                          id="name" 
                          value={fullName} 
                          onChange={(e) => setFullName(e.target.value)} 
                        />
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button 
                        onClick={handleUpdateProfile}
                        disabled={isUpdating}
                      >
                        {isUpdating ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Updating...
                          </>
                        ) : (
                          <>
                            <Save className="mr-2 h-4 w-4" />
                            Save Changes
                          </>
                        )}
                      </Button>
                    </CardFooter>
                  </Card>
                </TabsContent>
                
                <TabsContent value="chats" id="chats-tab">
                  <Card>
                    <CardHeader>
                      <CardTitle>Recent Conversations</CardTitle>
                      <CardDescription>
                        View your recent chat history with counselors
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      {isLoading ? (
                        <div className="flex justify-center py-8">
                          <Loader2 className="h-8 w-8 animate-spin text-mindblue-600" />
                        </div>
                      ) : recentChats.length === 0 ? (
                        <div className="text-center py-8">
                          <MessageSquare className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
                          <h3 className="text-lg font-medium">No chats yet</h3>
                          <p className="text-muted-foreground mt-2">
                            Start a conversation with a counselor to get support.
                          </p>
                          <Button 
                            className="mt-4"
                            onClick={() => navigate('/chat')}
                          >
                            Start a Conversation
                          </Button>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          {recentChats.map((chat) => (
                            <div key={chat.id} className="border rounded-lg p-4">
                              <div className="flex justify-between items-start mb-2">
                                <div className="flex items-center space-x-3">
                                  <Avatar className="h-10 w-10">
                                    <AvatarImage src={chat.counselor?.avatar_url} />
                                    <AvatarFallback className="bg-mindblue-100 text-mindblue-800">
                                      {getInitials(chat.counselor?.name || 'Counselor')}
                                    </AvatarFallback>
                                  </Avatar>
                                  <div>
                                    <h4 className="font-medium">{chat.counselor?.name || 'Counselor'}</h4>
                                    <p className="text-sm text-muted-foreground">
                                      {chat.counselor?.role || 'Counselor'}
                                    </p>
                                  </div>
                                </div>
                                <div className="flex items-center">
                                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                    chat.status === 'active' 
                                      ? 'bg-green-100 text-green-800 dark:bg-green-800/20 dark:text-green-400' 
                                      : 'bg-gray-100 text-gray-800 dark:bg-gray-800/20 dark:text-gray-400'
                                  }`}>
                                    {chat.status === 'active' ? 'Active' : 'Closed'}
                                  </span>
                                </div>
                              </div>
                              
                              <div className="mb-3">
                                <p className="text-sm line-clamp-2">
                                  {chat.latest_message ? (
                                    `${chat.latest_message.sender_type === 'student' ? 'You: ' : ''}${chat.latest_message.message_text}`
                                  ) : 'No messages yet'}
                                </p>
                              </div>
                              
                              <div className="flex justify-between items-center text-xs text-muted-foreground">
                                <div className="flex items-center">
                                  <Clock className="h-3 w-3 mr-1" />
                                  {formatDistanceToNow(new Date(chat.updated_at), { addSuffix: true })}
                                </div>
                                <span>{chat.message_count} messages</span>
                              </div>
                              
                              <div className="mt-3">
                                <Button 
                                  variant="outline" 
                                  className="w-full"
                                  onClick={() => navigate(`/chat/${chat.id}`)}
                                >
                                  View Conversation
                                </Button>
                              </div>
                            </div>
                          ))}
                          
                          {recentChats.length > 0 && (
                            <div className="flex justify-center mt-4">
                              <Button 
                                variant="link"
                                onClick={() => navigate('/chat')}
                              >
                                View All Chats
                              </Button>
                            </div>
                          )}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Profile;
