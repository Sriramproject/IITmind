
import { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useAuth } from '../context/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ArrowLeft, Send, BookmarkPlus, Bookmark, User, Paperclip, Info } from 'lucide-react';
import { formatRelative } from 'date-fns';

const ChatDetail = () => {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const [chat, setChat] = useState<any | null>(null);
  const [counselor, setCounselor] = useState<any | null>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isSending, setIsSending] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const { toast } = useToast();
  
  useEffect(() => {
    const fetchChatData = async () => {
      if (!id || !user) return;
      
      try {
        setIsLoading(true);
        
        // Fetch chat data
        const { data: chatData, error: chatError } = await supabase
          .from('chats')
          .select('*')
          .eq('id', id)
          .eq('student_id', user.id)
          .single();
          
        if (chatError) throw chatError;
        setChat(chatData);
        
        // Fetch counselor data
        if (chatData.counselor_id) {
          const { data: counselorData, error: counselorError } = await supabase
            .from('counselors')
            .select('*')
            .eq('id', chatData.counselor_id)
            .single();
            
          if (counselorError) throw counselorError;
          setCounselor(counselorData);
        }
        
        // Fetch messages
        const { data: messagesData, error: messagesError } = await supabase
          .from('messages')
          .select('*')
          .eq('chat_id', id)
          .order('created_at', { ascending: true });
          
        if (messagesError) throw messagesError;
        setMessages(messagesData);
      } catch (error: any) {
        console.error('Error fetching chat data:', error);
        toast({
          title: 'Error',
          description: 'Failed to load chat data.',
          variant: 'destructive'
        });
        navigate('/chat');
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchChatData();
    
    // Set up real-time subscription for new messages
    const channel = supabase
      .channel('schema-db-changes')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `chat_id=eq.${id}`
        },
        (payload) => {
          setMessages(prev => [...prev, payload.new]);
        }
      )
      .subscribe();
      
    return () => {
      supabase.removeChannel(channel);
    };
  }, [id, user, toast, navigate]);
  
  // Scroll to bottom when messages change
  useEffect(() => {
    if (scrollAreaRef.current) {
      const scrollContainer = scrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight;
      }
    }
  }, [messages]);
  
  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newMessage.trim() || !user || !id) return;
    
    try {
      setIsSending(true);
      
      const { error } = await supabase
        .from('messages')
        .insert({
          chat_id: id,
          sender_type: 'student',
          message_text: newMessage.trim(),
        });
        
      if (error) throw error;
      
      // Update chat's updated_at timestamp
      await supabase
        .from('chats')
        .update({ updated_at: new Date().toISOString() })
        .eq('id', id);
        
      setNewMessage('');
    } catch (error: any) {
      console.error('Error sending message:', error);
      toast({
        title: 'Error',
        description: 'Failed to send message. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setIsSending(false);
    }
  };
  
  const toggleSaveMessage = async (messageId: string, currentSaved: boolean) => {
    try {
      const { error } = await supabase
        .from('messages')
        .update({ is_saved: !currentSaved })
        .eq('id', messageId)
        .eq('sender_type', 'student');
        
      if (error) throw error;
      
      // Update local state
      setMessages(prev => 
        prev.map(msg => 
          msg.id === messageId ? { ...msg, is_saved: !currentSaved } : msg
        )
      );
    } catch (error: any) {
      console.error('Error toggling save message:', error);
      toast({
        title: 'Error',
        description: 'Failed to save/unsave message.',
        variant: 'destructive'
      });
    }
  };
  
  const formatMessageTime = (timestamp: string) => {
    return formatRelative(new Date(timestamp), new Date());
  };
  
  const getInitials = (name: string) => {
    if (!name) return 'C';
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        <div className="flex-grow flex items-center justify-center">
          <svg className="animate-spin h-12 w-12 text-mindblue-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
        </div>
        <Footer />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-6">
        <div className="max-w-4xl mx-auto">
          <div className="mb-6">
            <Button
              variant="ghost"
              className="gap-2 mb-4"
              onClick={() => navigate('/chat')}
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Chats
            </Button>
            
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={counselor?.avatar_url} />
                      <AvatarFallback className="bg-mindblue-100 text-mindblue-800">
                        {counselor ? getInitials(counselor.name) : 'C'}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <CardTitle>{counselor?.name || 'Counselor'}</CardTitle>
                      <div className="text-sm text-muted-foreground">
                        {counselor?.role || 'Counselor'} • {counselor?.specialization || 'General'}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    {chat?.is_anonymous && (
                      <div className="flex items-center gap-1 text-xs bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300 px-2 py-1 rounded-full">
                        <User className="h-3 w-3" />
                        Anonymous Mode
                      </div>
                    )}
                    <div className="text-xs bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300 px-2 py-1 rounded-full">
                      {chat?.status === 'active' ? 'Active' : 'Closed'}
                    </div>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="p-0">
                <div className="border-t border-border">
                  <ScrollArea className="h-[500px] p-4" ref={scrollAreaRef}>
                    {messages.length === 0 ? (
                      <div className="flex flex-col items-center justify-center h-full text-center">
                        <div className="bg-muted/50 p-6 rounded-full mb-4">
                          <User className="h-12 w-12 text-muted-foreground/70" />
                        </div>
                        <h3 className="text-lg font-medium">Start your conversation</h3>
                        <p className="text-muted-foreground max-w-md mt-2">
                          Send a message to begin chatting with {counselor?.name || 'your counselor'}.
                          All communications are private and secure.
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {messages.map((message) => (
                          <div 
                            key={message.id} 
                            className={`flex ${
                              message.sender_type === 'student' ? 'justify-end' : 'justify-start'
                            }`}
                          >
                            <div className="flex items-start max-w-[80%]">
                              {message.sender_type !== 'student' && (
                                <Avatar className="h-8 w-8 mr-2 mt-1 flex-shrink-0">
                                  {message.sender_type === 'ai' ? (
                                    <AvatarFallback className="bg-purple-100 text-purple-800 text-xs">AI</AvatarFallback>
                                  ) : (
                                    <>
                                      <AvatarImage src={counselor?.avatar_url} />
                                      <AvatarFallback className="bg-mindblue-100 text-mindblue-800 text-xs">
                                        {counselor ? getInitials(counselor.name) : 'C'}
                                      </AvatarFallback>
                                    </>
                                  )}
                                </Avatar>
                              )}
                              
                              <div className="flex flex-col">
                                <div 
                                  className={`px-4 py-3 rounded-lg ${
                                    message.sender_type === 'student'
                                      ? 'bg-mindblue-500 text-white'
                                      : message.sender_type === 'ai'
                                        ? 'bg-purple-100 dark:bg-purple-900/30 text-foreground'
                                        : 'bg-muted text-foreground'
                                  }`}
                                >
                                  {message.message_text}
                                </div>
                                <div className="flex items-center mt-1 space-x-2">
                                  <span className="text-xs text-muted-foreground">
                                    {formatMessageTime(message.created_at)}
                                  </span>
                                  {message.sender_type === 'student' && (
                                    <button 
                                      className="text-muted-foreground hover:text-foreground transition-colors"
                                      onClick={() => toggleSaveMessage(message.id, message.is_saved)}
                                      title={message.is_saved ? "Unsave message" : "Save message"}
                                    >
                                      {message.is_saved ? (
                                        <Bookmark className="h-3 w-3 text-mindblue-500" />
                                      ) : (
                                        <BookmarkPlus className="h-3 w-3" />
                                      )}
                                    </button>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </ScrollArea>
                </div>
                
                <div className="border-t border-border p-4">
                  <form onSubmit={sendMessage} className="flex flex-col space-y-2">
                    <div className="relative">
                      <Textarea
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        placeholder="Type your message..."
                        className="min-h-[100px] pr-12"
                        disabled={chat?.status !== 'active' || isSending}
                      />
                      <div className="absolute bottom-2 right-2 flex items-center space-x-1">
                        <Button
                          type="button"
                          size="icon"
                          variant="ghost"
                          className="h-8 w-8 rounded-full"
                          disabled={chat?.status !== 'active'}
                          title="Attach file (coming soon)"
                        >
                          <Paperclip className="h-4 w-4 text-muted-foreground" />
                        </Button>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <Button 
                        variant="outline" 
                        type="button"
                        size="sm"
                        className="text-xs"
                        disabled={chat?.status !== 'active'}
                      >
                        <Info className="h-3 w-3 mr-1" />
                        Escalate to Human Counselor
                      </Button>
                      <Button 
                        type="submit" 
                        disabled={!newMessage.trim() || chat?.status !== 'active' || isSending}
                      >
                        {isSending ? (
                          <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                        ) : (
                          <>
                            Send
                            <Send className="ml-2 h-4 w-4" />
                          </>
                        )}
                      </Button>
                    </div>
                  </form>
                  
                  {chat?.status !== 'active' && (
                    <div className="mt-3 text-sm text-muted-foreground text-center">
                      This conversation is closed. You cannot send new messages.
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default ChatDetail;
