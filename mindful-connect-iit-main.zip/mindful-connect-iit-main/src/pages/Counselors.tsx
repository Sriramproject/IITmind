
import { useState, useEffect } from 'react';
import { Search, Filter, Star, Mail, Phone, MessageSquare, Clock, MapPin, X, Info } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useNavigate, useLocation } from 'react-router-dom';
import { useToast } from '../hooks/use-toast';
import CounselorDetailModal from '../components/CounselorDetailModal';

// Sample counselor data (expanded from the preview on homepage)
const allCounselors = [
  {
    id: 1,
    name: "Dr. Priya Sharma",
    designation: "Clinical Psychologist",
    image: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80",
    email: "priya.sharma@iitm.ac.in",
    location: "Student Wellness Center, Block A",
    room: "Room 103",
    availability: "Mon-Fri: 10:00 AM - 4:00 PM",
    rating: 4.8,
    specialization: "Academic Stress",
    bio: "Dr. Sharma specializes in helping students manage academic pressure and exam anxiety. With over 10 years of experience in university counseling, she provides practical strategies for stress management and academic performance.",
    reviews: 127,
    phone: "+91-9876543210"
  },
  {
    id: 2,
    name: "Dr. Arun Kumar",
    designation: "Mental Health Counselor",
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80",
    email: "arun.kumar@iitm.ac.in",
    location: "Online Only",
    room: "Virtual Office",
    availability: "Tue, Thu: 2:00 PM - 7:00 PM",
    rating: 4.7,
    specialization: "Relationship Issues",
    bio: "Dr. Kumar focuses on interpersonal relationships, helping students navigate friendships, family dynamics, and romantic relationships. He creates a non-judgmental space to discuss personal matters.",
    reviews: 94,
    phone: "+91-9876543211"
  },
  {
    id: 3,
    name: "Dr. Shreya Patel",
    designation: "Wellness Coach",
    image: "https://images.unsplash.com/photo-1551836022-d5d88e9218df?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80",
    email: "shreya.patel@iitm.ac.in",
    location: "Student Health Center, Block C",
    room: "Room 205",
    availability: "Mon, Wed, Fri: 9:00 AM - 1:00 PM",
    rating: 4.9,
    specialization: "Health & Lifestyle",
    bio: "Dr. Patel combines mental health support with physical wellbeing strategies. She specializes in sleep issues, nutrition for brain health, and establishing healthy routines for busy students.",
    reviews: 156,
    phone: "+91-9876543212"
  },
  {
    id: 4,
    name: "Dr. Rahul Verma",
    designation: "Academic Advisor",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    email: "rahul.verma@iitm.ac.in",
    location: "Academic Block, Room 204",
    room: "Room 204",
    availability: "Tue, Thu: 10:00 AM - 3:00 PM",
    rating: 4.6,
    specialization: "Mental Health Support",
    bio: "Dr. Verma addresses anxiety, depression, and burnout among high-achieving students. He helps students develop coping mechanisms and resilience strategies for challenging academic environments.",
    reviews: 118,
    phone: "+91-9876543213"
  },
  {
    id: 5,
    name: "Dr. Meena Srinivasan",
    designation: "Career Counselor",
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=761&q=80",
    email: "meena.srinivasan@iitm.ac.in",
    location: "Career Development Center",
    room: "Room 101",
    availability: "Mon-Thu: 11:00 AM - 5:00 PM",
    rating: 4.7,
    specialization: "Academic Stress",
    bio: "Dr. Srinivasan helps students align their academic path with career aspirations, reducing stress related to future uncertainty. She offers guidance on internships, job preparation, and graduate studies.",
    reviews: 89,
    phone: "+91-9876543214"
  },
  {
    id: 6,
    name: "Dr. Karthik Rajan",
    designation: "Mindfulness Instructor",
    image: "https://images.unsplash.com/photo-1566492031773-4f4e44671857?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80",
    email: "karthik.rajan@iitm.ac.in",
    location: "Wellness Studio, Student Center",
    room: "Studio A",
    availability: "Wed, Fri: 9:00 AM - 2:00 PM",
    rating: 4.9,
    specialization: "Health & Lifestyle",
    bio: "Dr. Rajan specializes in mindfulness-based stress reduction and meditation techniques. He conducts both one-on-one sessions and group workshops for managing academic pressure through mindfulness.",
    reviews: 134,
    phone: "+91-9876543215"
  },
  {
    id: 7,
    name: "Dr. Anita Desai",
    designation: "Family Therapist",
    image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=688&q=80",
    email: "anita.desai@iitm.ac.in",
    location: "Online Only",
    room: "Virtual Office",
    availability: "Mon, Fri: 1:00 PM - 6:00 PM",
    rating: 4.8,
    specialization: "Relationship Issues",
    bio: "Dr. Desai specializes in family dynamics and helps students navigate complex family situations while managing academic responsibilities. She offers both individual and family counseling sessions.",
    reviews: 76,
    phone: "+91-9876543216"
  },
  {
    id: 8,
    name: "Dr. Vikram Menon",
    designation: "Psychiatrist",
    image: "https://images.unsplash.com/photo-1545167622-3a6ac756afa4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=712&q=80",
    email: "vikram.menon@iitm.ac.in",
    location: "Health Services, Medical Wing",
    room: "Room 302",
    availability: "Tue, Thu: 9:00 AM - 3:00 PM",
    rating: 4.8,
    specialization: "Mental Health Support",
    bio: "Dr. Menon provides psychiatric evaluation and treatment for students dealing with clinical depression, anxiety disorders, ADHD, and other mental health conditions that may impact academic performance.",
    reviews: 92,
    phone: "+91-9876543217"
  }
];

const Counselors = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSpecialization, setSelectedSpecialization] = useState<string | null>(null);
  const [selectedAvailability, setSelectedAvailability] = useState<string | null>(null);
  const [selectedCounselor, setSelectedCounselor] = useState<typeof allCounselors[0] | null>(null);
  const location = useLocation();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  // Get specialization from URL params if available
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const specialization = searchParams.get('specialization');
    if (specialization) {
      setSelectedSpecialization(specialization);
    }
  }, [location.search]);
  
  // Filter counselors based on search term and filters
  const filteredCounselors = allCounselors.filter(counselor => {
    const matchesSearch = searchTerm === '' || 
                          counselor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          counselor.designation.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          counselor.specialization.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesSpecialization = selectedSpecialization === null || 
                               counselor.specialization.toLowerCase().includes(selectedSpecialization.toLowerCase());
    
    // Simple availability filter - in a real app, this would be more sophisticated
    const matchesAvailability = selectedAvailability === null || 
                              (selectedAvailability === 'Online' ? 
                               counselor.location.includes('Online') : true);
    
    return matchesSearch && matchesSpecialization && matchesAvailability;
  });
  
  // Filter options
  const specializations = ['Academic Stress', 'Relationship Issues', 'Mental Health Support', 'Health & Lifestyle'];
  const availabilityOptions = ['Online', 'In-Person'];

  const handleCallCounselor = (counselor: typeof allCounselors[0]) => {
    toast({
      title: "Call initiated",
      description: `Connecting you to ${counselor.name}...`,
    });
    // In a real app, this would initiate a call
  };

  const handleChatCounselor = (counselor: typeof allCounselors[0]) => {
    toast({
      title: "Chat initiated",
      description: `Starting chat with ${counselor.name}...`,
    });
    // In a real app, this would start a chat
    navigate(`/chat?counselor=${counselor.id}`);
  };

  const handleViewProfile = (counselor: typeof allCounselors[0]) => {
    setSelectedCounselor(counselor);
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      
      <main className="flex-grow py-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h1 className="text-3xl font-bold text-foreground mb-2">Our Expert Counselors</h1>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Connect with professional counselors who understand the unique challenges of IIT Madras students
            </p>
          </div>
          
          {/* Search and Filters */}
          <div className="bg-card rounded-xl shadow-md p-4 mb-8 border border-border">
            <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4">
              <div className="flex-grow">
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Search by name, specialty, or role..."
                    className="block w-full pl-10 pr-3 py-2 bg-input border border-border rounded-lg focus:ring-mindblue-500 focus:border-mindblue-500 text-foreground"
                  />
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
                <div className="min-w-[200px]">
                  <select
                    value={selectedSpecialization || ''}
                    onChange={(e) => setSelectedSpecialization(e.target.value || null)}
                    className="block w-full py-2 px-3 bg-input border border-border rounded-lg focus:ring-mindblue-500 focus:border-mindblue-500 text-foreground"
                  >
                    <option value="">All Specializations</option>
                    {specializations.map((spec) => (
                      <option key={spec} value={spec}>{spec}</option>
                    ))}
                  </select>
                </div>
                
                <div className="min-w-[200px]">
                  <select
                    value={selectedAvailability || ''}
                    onChange={(e) => setSelectedAvailability(e.target.value || null)}
                    className="block w-full py-2 px-3 bg-input border border-border rounded-lg focus:ring-mindblue-500 focus:border-mindblue-500 text-foreground"
                  >
                    <option value="">All Availabilities</option>
                    {availabilityOptions.map((option) => (
                      <option key={option} value={option}>{option}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          </div>
          
          {/* Results Count */}
          <div className="mb-6 flex items-center">
            <Filter className="h-5 w-5 text-muted-foreground mr-2" />
            <span className="text-muted-foreground">
              Showing <span className="font-semibold text-foreground">{filteredCounselors.length}</span> of <span className="font-semibold text-foreground">{allCounselors.length}</span> counselors
            </span>
          </div>
          
          {/* Counselor Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredCounselors.map((counselor) => (
              <div key={counselor.id} className="mindcard overflow-hidden border border-border hover:border-mindblue-500/50">
                <div className="relative">
                  <img 
                    src={counselor.image} 
                    alt={counselor.name} 
                    className="w-full h-60 object-cover"
                  />
                  <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-sm rounded-full px-2 py-1 flex items-center">
                    <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                    <span className="text-sm font-medium ml-1 text-white">{counselor.rating}</span>
                    <span className="text-xs text-gray-300 ml-1">({counselor.reviews})</span>
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent text-white p-4">
                    <div className="inline-block px-2 py-1 bg-mindpurple-600 rounded-full text-xs font-semibold mb-2">
                      {counselor.specialization}
                    </div>
                  </div>
                </div>
                
                <div className="p-4 space-y-3">
                  <div>
                    <h3 className="font-bold text-lg text-foreground">{counselor.name}</h3>
                    <p className="text-muted-foreground text-sm">{counselor.designation}</p>
                  </div>
                  
                  <p className="text-foreground/80 text-sm line-clamp-3">{counselor.bio}</p>
                  
                  <div className="text-sm text-foreground/80">
                    <p className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-mindblue-600 flex-shrink-0" />
                      <span className="truncate">{counselor.email}</span>
                    </p>
                    <p className="mt-1 flex items-start gap-2">
                      <MapPin className="h-4 w-4 text-mindblue-600 flex-shrink-0 mt-1" />
                      <span>{counselor.location}</span>
                    </p>
                    <p className="mt-1 flex items-center gap-2">
                      <Clock className="h-4 w-4 text-mindblue-600 flex-shrink-0" />
                      <span>{counselor.availability}</span>
                    </p>
                  </div>
                  
                  <div className="pt-2 grid grid-cols-3 gap-2">
                    <button 
                      onClick={() => handleCallCounselor(counselor)}
                      className="btn-primary py-1.5 px-3 text-sm flex items-center justify-center gap-1"
                    >
                      <Phone className="h-4 w-4" />
                      <span>Call</span>
                    </button>
                    <button 
                      onClick={() => handleChatCounselor(counselor)}
                      className="btn-secondary py-1.5 px-3 text-sm flex items-center justify-center gap-1"
                    >
                      <MessageSquare className="h-4 w-4" />
                      <span>Chat</span>
                    </button>
                    <button 
                      onClick={() => handleViewProfile(counselor)}
                      className="bg-muted hover:bg-muted/70 text-foreground py-1.5 px-3 text-sm rounded-lg flex items-center justify-center gap-1"
                    >
                      <Info className="h-4 w-4" />
                      <span>Profile</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {/* Empty State */}
          {filteredCounselors.length === 0 && (
            <div className="text-center py-16 bg-card rounded-xl shadow-sm border border-border">
              <div className="mx-auto w-16 h-16 bg-muted rounded-full flex items-center justify-center mb-4">
                <Search className="h-8 w-8 text-muted-foreground" />
              </div>
              <h2 className="text-lg font-medium text-foreground mb-1">No counselors found</h2>
              <p className="text-muted-foreground mb-4">Try adjusting your search or filter criteria</p>
              <button 
                onClick={() => {
                  setSearchTerm('');
                  setSelectedSpecialization(null);
                  setSelectedAvailability(null);
                }}
                className="btn-outline"
              >
                Clear all filters
              </button>
            </div>
          )}
        </div>
      </main>
      
      <Footer />
      
      {/* Counselor Detail Modal */}
      {selectedCounselor && (
        <CounselorDetailModal 
          counselor={selectedCounselor} 
          onClose={() => setSelectedCounselor(null)}
          onCall={() => handleCallCounselor(selectedCounselor)}
          onChat={() => handleChatCounselor(selectedCounselor)}
        />
      )}
    </div>
  );
};

export default Counselors;
